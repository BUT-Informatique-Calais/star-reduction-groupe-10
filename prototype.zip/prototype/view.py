﻿# view.py
from PyQt6.QtWidgets import QWidget, QLabel, QPushButton, QSlider, QGridLayout, QApplication
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPixmap, QImage

class ImageView(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Star Reduction MVC")
        self.setGeometry(100, 100, 1200, 800)

        # Boutons
        self.load_button = QPushButton("Importer une image")
        self.save_button = QPushButton("Exporter l'image")

        # Sliders
        self.iter_slider = QSlider(Qt.Orientation.Horizontal)
        self.iter_slider.setMinimum(0)
        self.iter_slider.setMaximum(10)
        self.iter_slider.setValue(1)
        self.iter_slider.setTickInterval(1)
        self.iter_slider.setTickPosition(QSlider.TickPosition.TicksBelow)

        self.erode_slider = QSlider(Qt.Orientation.Horizontal)
        self.erode_slider.setMinimum(1)
        self.erode_slider.setMaximum(15)
        self.erode_slider.setValue(3)
        self.erode_slider.setTickInterval(1)
        self.erode_slider.setTickPosition(QSlider.TickPosition.TicksBelow)

        # Labels pour images
        self.label_orig = QLabel("Image originale")
        self.label_result = QLabel("Résultat")
        self.label_orig.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_result.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Taille des labels + adaptation automatique
        self.label_orig.setMinimumSize(500, 500)
        self.label_result.setMinimumSize(500, 500)
        self.label_orig.setScaledContents(True)
        self.label_result.setScaledContents(True)

        # Layout
        layout = QGridLayout()
        layout.addWidget(self.load_button, 0, 0)
        layout.addWidget(self.save_button, 0, 1)
        layout.addWidget(QLabel("Puissance d'érosion"), 1, 0)
        layout.addWidget(self.erode_slider, 2, 0)
        layout.addWidget(QLabel("Itérations"), 1, 1)
        layout.addWidget(self.iter_slider, 2, 1)
        layout.addWidget(self.label_orig, 0, 2, 3, 1)
        layout.addWidget(self.label_result, 3, 2, 3, 1)

        self.setLayout(layout)

    def update_image(self, label: QLabel, image):
        """Convertir numpy image en QPixmap et mettre à jour le label"""
        if image.ndim == 2:
            h, w = image.shape
            bytes_per_line = w
            qimage = QImage(image.data, w, h, bytes_per_line, QImage.Format.Format_Grayscale8)
        else:
            h, w, ch = image.shape
            bytes_per_line = ch * w
            import cv2 as cv
            image_rgb = cv.cvtColor(image, cv.COLOR_BGR2RGB)
            qimage = QImage(image_rgb.data, w, h, bytes_per_line, QImage.Format.Format_RGB888)
        pixmap = QPixmap.fromImage(qimage)
        label.setPixmap(pixmap)
