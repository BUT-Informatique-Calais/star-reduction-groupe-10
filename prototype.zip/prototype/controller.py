﻿# controller.py
from PyQt6.QtWidgets import QFileDialog

class ImageController:
    def __init__(self, model, view):
        self.model = model
        self.view = view

        # Connexion des événements
        self.view.load_button.clicked.connect(self.load_image)
        self.view.save_button.clicked.connect(self.save_image)
        self.view.iter_slider.valueChanged.connect(self.update_result)
        self.view.erode_slider.valueChanged.connect(self.update_result)

    def load_image(self):
        file_path, _ = QFileDialog.getOpenFileName(None, "Choisir un fichier FITS", "", "FITS Files (*.fits)")
        if file_path:
            self.model.load_fits(file_path)
            self.view.update_image(self.view.label_orig, self.model.image_orig)
            self.update_result()

    def save_image(self):
        if self.model.eroded_image is None:
            return
        file_path, _ = QFileDialog.getSaveFileName(None, "Enregistrer l'image", "", "PNG Files (*.png)")
        if file_path:
            import cv2 as cv
            cv.imwrite(file_path, self.model.eroded_image)

    def update_result(self):
        iterations = self.view.iter_slider.value()
        self.model.kernel_size = self.view.erode_slider.value()
        eroded = self.model.apply_erosion(iterations)
        self.view.update_image(self.view.label_result, eroded)
