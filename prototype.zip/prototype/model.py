﻿import numpy as np
import cv2 as cv
from astropy.io import fits
from typing import Optional


class ImageModel:
    def __init__(self):
        self.data: Optional[np.ndarray] = None
        self.image_orig: Optional[np.ndarray] = None
        self.eroded_image: Optional[np.ndarray] = None
        self.kernel_size: int = 3

    def load_fits(self, file_path):
        hdul = fits.open(file_path)
        self.data = hdul[0].data.astype(np.float32)
        hdul.close()

        # Gestion des images couleur et monochrome la couleur et le monochrome dépendent de la dimension des données du fits monochrome 2D, couleur 3D
        if self.data.ndim == 3:
            if self.data.shape[0] == 3:
                self.data = np.transpose(self.data, (1, 2, 0))

            # Couleur BGR à RGB 
            self.image_orig = ((self.data - self.data.min()) / (self.data.max() - self.data.min()) * 255).astype(np.uint8)
            self.image_orig = cv.cvtColor(self.image_orig, cv.COLOR_RGB2BGR)
        else:
            # Monochrome
            self.image_orig = ((self.data - self.data.min()) / (self.data.max() - self.data.min()) * 255).astype(np.uint8)

        self.eroded_image = self.image_orig.copy()


    def apply_erosion(self, iterations=1):
        if self.image_orig is None:
            return None
        kernel = np.ones((self.kernel_size, self.kernel_size), np.uint8)
        self.eroded_image = cv.erode(self.image_orig, kernel, iterations=iterations)
        return self.eroded_image
